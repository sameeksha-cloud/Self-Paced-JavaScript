//Write a program to find the factorial of a number.

function factorial(num){

    if(num == 0){
        return fact
    }
    else if(num<0){
        fact = "Error"
    }
    else{
    for(let i=1;i<=num;i++){
        fact = fact*i
    }
}
return fact
}

var fact = 1
var result = factorial(4)
console.log(result)