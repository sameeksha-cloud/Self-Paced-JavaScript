## Conditional Statement
1. if-else
2. switch

### if-else statement

```
<script>
var num = 20
if(num>0){
    console.log("Number is greater than zero")
}
else if(num<0){
    console.log("Number is less than zero")
}
else{
    console.log("Number is equal to zero)
}
</script>

OUTPUT: Number is greater than zero
```

### swtich statement
used to execute one code from multiple expression.

```
<script>
var garde = 'B'
var result = ''
switch(grade){
    case 'A':
    result = "Pass"
    break;
    case 'B':
    result = "Pass"
    break;
    case 'D':
    result = "fail"
    break;
    deafult;
    result = "No Grade"
}
console.log(result)
</script>

Ouput: Pass
```
