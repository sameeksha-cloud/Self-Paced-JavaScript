## Operators 

Operators are used to perform operations on operands.

1. Airthmetic 
2. Comparison
3. Bitwise
4. Logical
5. Assignment
6. Special Operators


### Airthmetic
- '+'
- '-'
- '*'
- /
- %
- ++  Increment
- --  Decrement


### Comparison
- ==    is equal to compare only value
- ===   compare data type and value both
- != 
- !==
- '>'
- <
- <=
- '>='

### Bitwise Operators
- &
- |
- ^
- ~
- <<
- '>>'
- '>>>'


### logical 
- &&
- ||
- !

### Assignment Operators
- =
- +=
- -=
- *=
- /=
- %=

### Special
- (?:)   ternary operator like if-else 
- ,
- typeof
- new
- in
- instanceof
- delete
- void
- yield
